import { combineReducers } from "redux";
import CountriesReducer from './countries';

const rootReducer = combineReducers({
    CountriesReducer
});

export default rootReducer;