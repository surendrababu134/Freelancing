export const GET_COUNTRIES_LIST = "/listcountries";
export const POST_COUNTRY = "/add";