import React from 'react';
import Select from 'react-select';
const SelectSearch = (props) => {
    return (
        <Select {...props} />
    )
}

export default SelectSearch
