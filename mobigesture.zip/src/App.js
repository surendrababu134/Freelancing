
import './App.css';

//Containers loading
import Container from './containers';
function App() {
  return (
    <div>
      <Container />
    </div>
  );
}

export default App;
